public interface ColorAPI {
    public String moving_around();
}