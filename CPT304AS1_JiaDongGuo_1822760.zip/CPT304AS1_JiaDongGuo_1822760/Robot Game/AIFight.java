public class AIFight {
        
    public static void main(String[] args){
    //partI create robots, name them


        // 10 robots create
        Robot r1 = new Robot("HG1", 49, 114);        //#1 Robot
        Robot r2 = new Robot("HG2", 49, 114);     //#2 Robot
        Robot r3 = new Robot("HG3", 49, 114);     //#3 Robot
        Robot r4 = new Robot("SMG1", 77, 10);    //#4 Robot
        Robot r5 = new Robot("SMG2", 77, 10);    //#5 Robot
        Robot r6 = new Robot("SMG3", 77, 10);   //#6 Robot
        Robot r7 = new Robot("AR1", 10, 475);    //#7 Robot
        Robot r8 = new Robot("AR2", 10, 475);    //#8 Robot
        Robot r9 = new Robot("AR3", 10, 475);  //#9 Robot
        Robot r10 = new Robot("AR4", 10, 475);       //#10 Robot

        // Colorize the robots 
        r1.setDrawAPI(new RedBot());
        r2.setDrawAPI(new RedBot());
        r3.setDrawAPI(new RedBot());
        r4.setDrawAPI(new BlueBot());
        r5.setDrawAPI(new BlueBot());
        r6.setDrawAPI(new BlueBot());
        r7.setDrawAPI(new GreenBot());
        r8.setDrawAPI(new GreenBot());
        r9.setDrawAPI(new GreenBot());
        r10.setDrawAPI(new GreenBot());



        // create enemies
        Enemy e1 = new Enemy("Dio", 10, 5);          // (name, armor, speed)
        Enemy e2 = new Enemy("Kira", 61, 50);
        Enemy e3 = new Enemy("Pucci", 14, 80);




    //PartII Fighting

        //System.out.println("r1 has the ability: " + r1.specialAction());
        //System.out.println("r4 has the ability: " + r4.specialAction());
        //System.out.println("r7 has the ability: " + r7.specialAction());
        r1.Attack(e1);
        r2.Attack(e2);
        r3.Attack(e3);
        r4.Attack(e1);
        r5.Attack(e2);
        r6.Attack(e3);
        r7.Attack(e1);
        r8.Attack(e2);
        r9.Attack(e3);
        r10.Attack(e1);

    }

}
