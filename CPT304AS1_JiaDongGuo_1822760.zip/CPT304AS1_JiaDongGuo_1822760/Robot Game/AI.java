public abstract class AI{
    protected Weapon weapon;      
    protected ColorAPI colorAPI;              // 2 interfaces

    public void setDrawAPI(ColorAPI colorAPI){          //for bridge pattern, strategy pattern
        this.colorAPI = colorAPI;
    }

    String name= "";
    int armor_s = 114514;
    String equipment = "rifle";
    Weapon p = WeaponFactory.getWeapon(equipment);
    int speed = 1919810;      //unit: km/h                    // default parameters
   

    public AI(String AIname, int AIarmor, int AIspeed){         //constructor
            this.name = AIname;
            this.armor_s = AIarmor;  
            this.speed = AIspeed;   
    }


    public String name() {                                      // object name
        return name;
    }

    public void rename(String newname) {                        // rename object
        name = newname;
    }
    
    public int armor() {                                        // check armor points
        return armor_s;
    }

    public Weapon weapon(){                                     // implement Weapon methods
        return p;
    }

    public void requip(String newequip){                        // change other weapon
         equipment = newequip;
         weapon();
    }

    public String specialAction(){                              // for Strategy pattern
        return colorAPI.moving_around();
    }
    
    public void Changeweapon(int armor_p_else, int speed_else) {                            // help to choose appropriate weapon
        if((speed_else > 60) && (speed_else <= 120)){         // speed judgement
            
            if(armor_p_else > 50){                           
                System.out.println("depoly laser");
                this.requip("laser");
                System.out.println("Hit! Caused " + (this.weapon().getthedamage()-armor_p_else) + " damage!");
            }else{
                System.out.println("activate rifle");
                this.requip("rifle");
                System.out.println("Hit! Caused " + (this.weapon().getthedamage()-armor_p_else) + " damage!");
            }
          
        }else if (speed_else > 120){                            // only use laser
            System.out.println("depoly laser");
            this.requip("laser");
            System.out.println("Hit! Caused " + (this.weapon().getthedamage()-armor_p_else) + " damage!");
        
        }else{                                                  // spped <= 60, armor judgement
            
            if(armor_p_else < 20){
                System.out.println("pick up spear");
                this.requip("spear");
                System.out.println("Hit! Caused " + (this.weapon().getthedamage()-armor_p_else) + " damage!");
            }else if(armor_p_else > 50){
                System.out.println("depoly laser");
                this.requip("laser");
                System.out.println("Hit! Caused " + (this.weapon().getthedamage()-armor_p_else) + " damage!");
            }else{
                System.out.println("activate rifle");
                this.requip("rifle");
                System.out.println("Hit! Caused " + (this.weapon().getthedamage()-armor_p_else) + "damage!");
            }
             
         }
        
 
    }
    


    
    public void Attack(AI oppo) {                               // Attack procedure, print each steps
   
         System.out.println(this.name() + " will attack " + oppo.name());
         System.out.println("the opponent " + oppo.name() + " armor is " + oppo.armor() + " points");
         System.out.println("the opponent " + oppo.name() + " speed is " + oppo.moving() + " points");
         this.Changeweapon(oppo.armor(), oppo.moving());
         System.out.println(this.name() + " said: " + this.specialAction());
         System.out.println( this.name() + " used " + this.weapon().gettheweapon()+ " to attack the "+ oppo.name());
         System.out.println("Combat finish.");
         System.out.println("");

        }



    public int moving() {                       // return speed

        return speed;
    
    }



}
