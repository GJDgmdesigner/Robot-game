class spear implements Weapon{
    public String gettheweapon(){
        return "spear";
    }
    public int getthedamage(){
        return 1919;
    }
}
