public class BlueBot implements ColorAPI{
   
    @Override 
    public String moving_around(){
        return "I can jumping towards the enemy!";
    }
}
