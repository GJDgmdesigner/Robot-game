public class Robot extends AI{

    public Robot(String AIname, int AIarmor, int AIspeed) {
        super(AIname, AIarmor, AIspeed);

    }

    @Override
    public String name() {
        return "Robot "+ name;
    }


}
