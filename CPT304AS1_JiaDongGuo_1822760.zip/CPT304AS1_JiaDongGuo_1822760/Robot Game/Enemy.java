public class Enemy extends AI{


    public Enemy(String AIname, int AIarmor, int AIspeed) {
        super(AIname, AIarmor, AIspeed);

    }

    @Override
    public String name() {
        return "Enemy "+name;
    }
 
}
