public class RedBot implements ColorAPI{
   
    @Override 
    public String moving_around(){
        return "I can swimming towards the enemy!";
    }

}

