class rifle implements Weapon{
    public String gettheweapon(){
        return "rifle";
    }
    public int getthedamage(){
        return 514;
    }
}
