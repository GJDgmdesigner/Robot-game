public class GreenBot implements ColorAPI{
    
    @Override 
    public String moving_around(){
        return "I can flying towards the enemy!";
    }

}
