class laser implements Weapon{
    public String gettheweapon(){
        return "laser";
    }
    public int getthedamage(){
        return 400;
    }
}
