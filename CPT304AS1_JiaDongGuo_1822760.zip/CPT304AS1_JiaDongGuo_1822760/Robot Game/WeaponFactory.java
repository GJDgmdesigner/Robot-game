public abstract class WeaponFactory{
   
    public static Weapon getWeapon(String equipment){
        if(equipment == "spear"){
            return new spear();
        }else if(equipment == "rifle"){
            return new rifle();
        }else if(equipment == "laser"){
            return new laser();
        }
        return new spear();

    }


}