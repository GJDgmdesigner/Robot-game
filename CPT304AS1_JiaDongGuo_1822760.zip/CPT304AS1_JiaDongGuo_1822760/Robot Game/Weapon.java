public interface Weapon{
   public String gettheweapon();
   public int getthedamage();
}